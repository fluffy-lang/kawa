#ifndef VIRTUALDRAGON_OPCODE_STRUCT_H
#define VIRTUALDRAGON_OPCODE_STRUCT_H

#include "datatypes.h"

//
// Reserved for the future
//

//typedef struct INSTRUCTION_INFO INSTRUCTION_INFO;
//struct INSTRUCTION_INFO {
//    // example: basic, flow, integer arithmetic, compare, logic etc...
//    char*   category;
//    // example: push or call or mov etc...
//    char*   mnemonic;
//    char*   template;
//    duint32 opcode;
//    // example: 0|000|0000000|00000|0000000000000000-sw|f|op|r|imm
//    char*   instructionMap;
//    // example: dst += src or dst += imm
//    char*   description;
//};

#endif //VIRTUALDRAGON_OPCODE_STRUCT_H
