#ifndef VIRTUALDRAGON_FORMAT_L_H
#define VIRTUALDRAGON_FORMAT_L_H

#include "dvm.h"

// L - list format
VOID DVM_FASTCALL format_l64(DVM* state, duint64 instruction);

#endif //VIRTUALDRAGON_FORMAT_L_H
