#ifndef VIRTUALDRAGON_FORMAT_I64_H
#define VIRTUALDRAGON_FORMAT_I64_H

#include "dvm.h"

// I - immediate format
VOID DVM_FASTCALL format_i64(DVM* state, duint64 instruction);

#endif // VIRTUALDRAGON_FORMAT_I64_H
