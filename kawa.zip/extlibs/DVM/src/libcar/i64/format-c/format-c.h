#ifndef VIRTUALDRAGON_FORMAT64_C_H
#define VIRTUALDRAGON_FORMAT64_C_H

#include "dvm.h"

// jump 48 bit imm
VOID DVM_FASTCALL format_c64(DVM* state, duint64 instruction);

#endif //VIRTUALDRAGON_FORMAT64_C_H
