#ifndef VIRTUALDRAGON_FORMAT_R_H
#define VIRTUALDRAGON_FORMAT_R_H

#include "dvm.h"

// R - register format
VOID DVM_FASTCALL format_r32(DVM* state, duint32 instruction);

#endif //VIRTUALDRAGON_FORMAT_R_H
