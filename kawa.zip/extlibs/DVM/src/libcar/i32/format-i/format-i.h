#ifndef VIRTUALDRAGON_FORMAT_I32_H
#define VIRTUALDRAGON_FORMAT_I32_H

#include "dvm.h"

// I - immediate format
VOID DVM_FASTCALL format_i32(DVM* state, duint32 instruction);

#endif // VIRTUALDRAGON_FORMAT_I32_H
