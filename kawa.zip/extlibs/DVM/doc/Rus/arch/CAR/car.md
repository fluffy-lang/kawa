# Cybegon Aachitecture

# CAR Instruction formats
- N-Type (NOP)
- I-Type (Immediate)
- R-Type (Register)
- F-Type (Float)
- J-Type (Jump)
- C-Type (Call)
- T-Type (Tensor)


# Future
- L-Type (Long)
