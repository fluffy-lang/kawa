# Format-j - Jump

| Mode  | Format | OP     | Immediate |
|-------|--------|--------|-----------|
| 1 bit | 3 bit  | 4 bit  | 24 bit    |

### Opcodes

| Category | Mnemonic | Opcode | OPERAND1 | OPERAND2 | Description                                                    |
|----------|----------|--------|----------|----------|----------------------------------------------------------------|
| Flow     | MOV      | 0x00   | RegDst   | IMM16    | RegDst = IMM16                                                 |
