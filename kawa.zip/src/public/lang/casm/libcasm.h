#ifndef KAWA_LIBCASM_H
#define KAWA_LIBCASM_H



void init();
void load();
void unload();

#endif //KAWA_LIBCASM_H
