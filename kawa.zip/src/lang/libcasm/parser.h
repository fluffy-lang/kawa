#ifndef KAWA_PARSER_H
#define KAWA_PARSER_H

#include "casmdef.h"
#include "sllexer.h"

dint kGetCarFormat(KExpression* expression);
KExpression kParseExpression(SLLexerContext* ctx);

#endif //KAWA_PARSER_H
