#include "parser.h"

#include "casmdef.h"

#include "formats.h"

void kParseFirst(KExpression* expression, SLToken* token);
void kParseDirective(KExpression* expression, SLToken* token);
void kParseKeyword(KExpression* expression, SLToken* token);

static const SLTokenType patterns[][8] = {
        {T_DIRECTIVE, T_IDENTIFIER, T_NULL},

        {T_LABEL, T_NULL},

        //{T_KEYWORD, T_REGISTER, T_REGISTER, T_CONSTANT, T_NULL}, // op r1, r1, 10
        {T_KEYWORD, T_REGISTER, T_CONSTANT, T_NULL}, // op r1, 10
        {T_KEYWORD, T_CONSTANT, T_NULL}, // op 10

        {T_KEYWORD, T_REGISTER, T_REGISTER, T_REGISTER, T_NULL}, // op r0, r0, r0
        {T_KEYWORD, T_REGISTER, T_REGISTER, T_NULL}, // op r0, r0
        {T_KEYWORD, T_REGISTER, T_NULL}, // op r0
        {T_KEYWORD, T_NULL}, // ret

        {T_KEYWORD, T_IDENTIFIER, T_NULL}, // op r0

        {T_NULL}
};

static int formatTable[] = {
    CAR_FORMAT_N,
    CAR_FORMAT_N,
    CAR_FORMAT_I,
    CAR_FORMAT_I,
    CAR_FORMAT_R,
    CAR_FORMAT_R,
    CAR_FORMAT_R,
    CAR_FORMAT_I,
    CAR_FORMAT_C,
    EOF
};

dint kGetCarFormat(KExpression* expression)
{
    for (int i = 0; patterns[i][0] != T_NULL; ++i)
        for (int j = 0; patterns[i][j] != T_NULL; ++j)
            if (expression->tokens[j].type == patterns[i][j] && patterns[i][j + 1] == T_NULL)
                return formatTable[i];
    return EOF;
}

KExpression kParseExpression(SLLexerContext* ctx)
{
    KExpression kExpr = { 0 };
    for (SLToken token = sl_getNextToken(ctx);; token = sl_getNextToken(ctx)) {
        if (kExpr.tokenCount != 0)
            if (token.type == T_ENDL || token.type == T_EOF)
                return kExpr;

        if (token.type == T_EOF)
            return (KExpression) {EOF, {0}};

        if (kExpr.tokenCount == 0)
            kParseFirst(&kExpr, &token);
        else if (kExpr.tokens[0].type == T_DIRECTIVE)
            kParseDirective(&kExpr, &token);
        else if (kExpr.tokens[0].type == T_KEYWORD)
            kParseKeyword(&kExpr, &token);
    }
}

void kParseFirst(KExpression* expression, SLToken* token)
{
    switch (token->type) {
        case T_DIRECTIVE:
        case T_KEYWORD: {
            expression->tokens[expression->tokenCount++] = *token;
            break;
        }
        case T_ENDL:
        case T_LABEL: {
            break;
        }
        default: {
            printf("Expect DIRECTIVE or KEYWORD!\n");
            break;
        }
    }
}

void kParseDirective(KExpression* expression, SLToken* token)
{
    switch (token->type) {
        case T_IDENTIFIER:
        case T_CONSTANT: {
            expression->tokens[expression->tokenCount++] = *token;
            break;
        }
        case '.':
        case ',': {
            break;
        }
        default: {
            printf("T_DIRECTIVE expected IDENTIFIER or CONSTANT\n");
            break;
        }
    }
}

void kParseKeyword(KExpression* expression, SLToken* token)
{
    switch (token->type) {
        case T_IDENTIFIER:
        case T_CONSTANT:
        case T_REGISTER: {
            expression->tokens[expression->tokenCount++] = *token;
            break;
        }
        case ',': {
            break;
        }
        default: {
            printf("T_DIRECTIVE expected REGISTER or IDENTIFIER or CONSTANT\n");
            break;
        }
    }
}
