#ifndef KAWA_CASMDEF_H
#define KAWA_CASMDEF_H

#include "datatypes.h"
#include "sllexer.h"

typedef struct KExpression KExpression;

struct KExpression
{
    dint    tokenCount;
    SLToken tokens[8];
};

#endif //KAWA_CASMDEF_H
