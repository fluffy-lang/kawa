#include "code-gen.h"

#include "formats.h"
#include "car-gen.h"

#include "slconfig.h"

#include "parser.h"

KModule* createModule(char* moduleName);
int kGen(KCompiler* compiler, KExpression* expression, dint32 format);

struct KModule* container[256] = { 0 };

struct ModuleContainer
{
    int count;
    struct KModule* modules[256];
};

struct ModuleContainer moduleContainer = { 0 };

void step(KCompiler* compiler, KExpression expression)
{
    dint format = kGetCarFormat(&expression);
    if (format == EOF)
        printf("step ERROR");

    if (format == CAR_FORMAT_N && expression.tokens[0].type == T_DIRECTIVE) {
        if (expression.tokens[0].tokenInfo == 1) {
            compiler->currentModule = createModule(expression.tokens[0].identString);
        }

        return;
    }

    kGen(compiler, &expression, format);
    printf("pCode: %x\n", compiler->unalignedByteCode);
//    if (compiler->unalignedByteCode != 0) {
//        duint32 tmp = compiler->unalignedByteCode;
//        kGen(compiler, &expression, format);
//
//        if (compiler->unalignedByteCode != 0) {
//            car_op32Pack64(tmp, compiler->unalignedByteCode);
//            compiler->unalignedByteCode = 0;
//        }
//
//
//    }


}

int kGen(KCompiler* compiler, KExpression* expression, dint32 format)
{
    switch (format) {
        case CAR_FORMAT_I: {
            compiler->unalignedByteCode = car_emit_op32(format,
                                                        expression->tokens[0].tokenInfo,
                                                        expression->tokens[1].tokenInfo,
                                                        NO_REG, NO_REG, NO_REG,
                                                        (duint32)expression->tokens[2].value);
            break;
        }
        case CAR_FORMAT_R: {
            compiler->unalignedByteCode = car_emit_op32(format,
                                                        expression->tokens[0].tokenInfo,
                                                        expression->tokens[1].tokenInfo,
                                                        expression->tokens[1].tokenInfo,
                                                        expression->tokens[2].tokenInfo,
                                                        NO_REG,
                                                        0);
            break;
        }
        default:
            compiler->unalignedByteCode = 0;
            break;
    }

    return 32;
}

//void directiveHandler(SLToken token);
//void registerHandler(SLToken token);
//
//void directiveHandler(SLToken token)
//{
//    switch (token.tokenInfo) {
//        case 1: {
//            moduleContainer.modules[moduleContainer.count++] = createModule(token.identString);
//        }
//    }
//}

KModule* createModule(char* moduleName)
{
    KModule* m = SL_MALLOC(sizeof(struct KModule));
    SL_BZERO(m, sizeof(struct KModule));

    strcpy(m->section.name, moduleName);
    m->data = SL_MALLOC(MB(1));

    return m;
}