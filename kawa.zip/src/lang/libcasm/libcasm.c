#include "libcasm.h"

#include <slreader.h>
#include <sllexer.h>

#include "casm-dictionary.h"

#include "parser.h"
#include "code-gen.h"

static SLLexerContext* ctx = NULL;

void printExpression(KExpression* expression);

void load()
{
    ctx = sl_createLexerContext(lexList, lexStageLst);
    sl_openFile(ctx, "I:/casm.asm");

    KCompiler c;
    KExpression expression = kParseExpression(ctx);
    do {
//        printExpression(&expression);
        step(&c, expression);

        expression = kParseExpression(ctx);
    } while (expression.tokens[0].type != T_NULL);

    sl_closeFile(ctx);
    sl_freeLexerContext(ctx);
}

void printExpression(KExpression* expression)
{
    if (expression->tokens[0].type == T_NULL)
        return;

    printf("---------------GEN!---------------\n");
    for (int i = 0; i < expression->tokenCount; ++i) {
        switch (expression->tokens[i].type) {
            case T_DIRECTIVE:
            case T_LABEL:
            case T_IDENTIFIER:
            case T_KEYWORD:
            case T_REGISTER:
            case T_STRING: {
                printf("%s name: %s\n", sl_getTokenType(ctx, expression->tokens[i]).data, expression->tokens[i].identString);
                break;
            }
            case T_CONSTANT: {
                if (expression->tokens[i].tokenInfo == 1)
                    printf("%s name: %s\n", sl_getTokenType(ctx, expression->tokens[i]).data, expression->tokens[i].identString);
                else
                    printf("%s value: %f\n", sl_getTokenType(ctx, expression->tokens[i]).data, expression->tokens[i].value);
                break;
            }
            default: {
                printf("%s\n", sl_getTokenType(ctx, expression->tokens[i]).data);
                break;
            }
        }
    }
    printf("---------------END!---------------\n");
}

void unload()
{

}
