#ifndef KAWA_CODE_GEN_H
#define KAWA_CODE_GEN_H

#include "datatypes.h"

#include "geff.h"

#include "casmdef.h"

typedef struct KCompiler KCompiler;
typedef struct KLabelList KLabelList;
typedef struct KLabel KLabel;
typedef struct KModule KModule;

struct KLabel
{
    char*   name;
    ADDRESS address;
};

struct KLabelList
{
    KLabelList* prev;
    KLabel label;
    KLabelList* next;
};

struct KModule
{
    struct GEFF_SECTION section;

    duint64 dataSize;
    MEMORY  data;
};

struct KCompiler
{
    duint32     unalignedByteCode;
    KModule*    currentModule;
    KLabelList  list;
};

void step(KCompiler* compiler, KExpression expression);

#endif //KAWA_CODE_GEN_H
